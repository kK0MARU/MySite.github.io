<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Главная</title>
        <link rel="stylesheet" href=
"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="./style.css">
</head>
<body>
    <header>
        <div class="header_block">
            <div class="links_list">
                <ul>
                    <li><a href="#about_me_block" class="link">Обо мне</a></li>
                    <li><a href="#social_links" class="link">Ссылки</a></li>
                    <li><a href="#portfolio" class="link">Потфолио</a></li>
                </ul>
            </div>
        </div>
    </header>
</body>
</html>